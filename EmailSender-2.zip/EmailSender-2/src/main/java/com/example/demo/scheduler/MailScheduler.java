package com.example.demo.scheduler;

public class MailScheduler {

}
