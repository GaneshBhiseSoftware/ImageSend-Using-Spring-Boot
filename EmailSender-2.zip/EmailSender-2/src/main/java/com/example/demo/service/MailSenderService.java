package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.User;

public interface MailSenderService {

	void mailSend(User user);

	List<User> getUsers();

}
