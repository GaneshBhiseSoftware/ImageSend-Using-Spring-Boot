package com.example.demo.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.example.demo.entity.User;
import com.example.demo.repo.MailSenderRepo;

@Service
public class MailSenderServiceImpl implements MailSenderService {

	@Autowired
	MailSenderRepo repo;
	@Autowired
	JavaMailSender javaMailSender;

	Map<Integer, User> map = new HashMap<>();

	@Override
	public void mailSend(User user) {

		SimpleMailMessage msg = new SimpleMailMessage();
		msg.setTo(user.getEmail());
		msg.setSubject("hello");
		msg.setText(user.getName());

		javaMailSender.send(msg);

		User save = repo.save(user);
		map.put(save.getId(), save);
	}

	@Override
	public List<User> getUsers() {
		return repo.findAll();

	}

}
